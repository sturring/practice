ROOM_ID = "room_5673"
FILTERS = ['blur']
THEME = "light"
